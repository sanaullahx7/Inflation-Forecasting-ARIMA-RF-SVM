#Reading and joining data in csv--------------------------------------------------
library(dplyr)
library(readr)
library(purrr)
file_list <- list.files(path = ".", pattern = "\\.csv$", full.names = TRUE)
dfs <- lapply(file_list, read.csv)
merged_data <- Reduce(function(x, y) merge(x, y, by = "observation_date"), dfs)
write.csv(merged_data, "final_dataset.csv", row.names = FALSE)

#summary--------------------------------------------------------------------------

summary(merged_data)

#whisker and box plots------------------------------------------------------------

library(ggplot2)
library(tidyr)

long_data <- merged_data %>%
  pivot_longer(cols = -1, names_to = "variable", values_to = "value")

library(gridExtra)
library(grid)
# List to store individual plots
plot_list <- list()

colors <- c("red", "blue", "green", "purple", "orange", "pink", "yellow", "cyan")

# Loop through each variable and generate plots
for (i in seq_along(unique(long_data$variable))) {
  var <- unique(long_data$variable)[i]
  
  p <- ggplot(long_data[long_data$variable == var, ], aes(x = variable, y = value, fill = variable)) +
    geom_boxplot(outlier.colour = "red", outlier.shape = 8) +  # Customize outlier color and shape
    scale_fill_manual(values = colors[i %% length(colors) + 1]) +  # Apply different color for each plot
    theme_minimal() +
    labs(title = paste("Box and Whisker Plot for", var), x = "____________________________", y = "Value") +
    theme(axis.text.x = element_text(angle = 0, hjust = 1), legend.position = "none")  # Rotate x-axis labels for clarity
  
  plot_list[[var]] <- p  # Add the plot to the list
}

# Arrange all plots in a grid and save as a PNG file
png("boxplots_all_variables.png", width = 10, height = 8, units = "in", res = 650)
grid.arrange(grobs = plot_list, ncol = 3)  # Arrange the plots in 2 columns (adjust as needed)
dev.off()


#scatterplot__________________________________________________________________________

target_var <- "CPIAUCSL"


# Get the list of other variables (excluding the target)
other_vars <- setdiff(names(merged_data), c("CPIAUCSL","observation_date"))

# Create a list to hold plots
plot_list <- list()

# Loop to generate scatter plots of target_var vs each other variable
for (var in other_vars) {
  p <- ggplot(merged_data, aes_string(x = var, y = target_var)) +
    geom_point(color = "steelblue") +
    theme_minimal() +
    labs(title = paste(target_var, "vs", var),
         x = var, y = target_var)
  plot_list[[var]] <- p
}

# Save all plots in a grid layout to one file
png("scatterplots_target_vs_all.png", width = 12, height = 8, units = "in", res = 650)
grid.arrange(grobs = plot_list, ncol = 3)  # Adjust ncol based on how many plots you have
dev.off()