# =============================
# Load necessary libraries
# =============================
library(readr)
library(forecast)
library(tseries)
library(ggplot2)

# =============================
# 1. Load the dataset
# =============================
data <- read_csv("final_dataset.csv")
data$observation_date <- as.Date(data$observation_date)

# =============================
# 2. Create a time series object for CPI (quarterly data)
# =============================
cpi_ts <- ts(data$CPIAUCSL, start = c(2010, 2))

# Visualize the Time Series
plot(cpi_ts, main = "CPI Time Series (Original)", col = "blue")

# =============================
# 3. Train-Test Split (70% Train, 30% Test)
# =============================
train_size <- floor(0.7 * length(cpi_ts))
train_data <- window(cpi_ts, end = c(2010 + (train_size - 1) %/% 4, (train_size - 1) %% 4 + 1))
test_data <- window(cpi_ts, start = c(2010 + (train_size) %/% 4, (train_size) %% 4 + 1))

# Visualize the Split
plot(train_data, main = "Train and Test Split", col = "blue")
lines(test_data, col = "red")
legend("topleft", legend = c("Training Data", "Test Data"), col = c("blue", "red"), lty = 1)

# =============================
# 4. ACF and PACF Plots
# =============================
par(mfrow = c(1, 2)) # 1 row, 2 columns
acf(diff(diff(train_data)), main = "ACF of Differenced Train Data")
pacf(diff(diff(train_data)), main = "PACF of Differenced Train Data")
par(mfrow = c(1, 1)) # Reset to single plot

# =============================
# 5. Fit ARIMA model to Training Data
# =============================
cat("\nFitting ARIMA Model...\n")
model <- auto.arima(train_data)
summary(model)

# =============================


# =============================
# 7. Plot Actual vs Fitted CPI Values
# =============================
plot(train_data, main = "Actual vs Fitted CPI (Training Data)", ylab = "CPI", col = "black")
lines(fitted(model), col = "red", lty = 2)
legend("topleft", legend = c("Actual (Train)", "Fitted"), col = c("black", "red"), lty = c(1, 2))

# =============================
# 8. Evaluate Model Performance
# =============================
fitted_vals <- fitted(model)
actual_vals <- as.numeric(train_data)

# MSE Calculation
mse <- mean((actual_vals - fitted_vals)^2)
cat("\nTraining Data - Mean Squared Error (MSE):", mse, "\n")

# R² Calculation
ss_total <- sum((actual_vals - mean(actual_vals))^2)
ss_res <- sum((actual_vals - fitted_vals)^2)
r_squared <- 1 - (ss_res / ss_total)
cat("Training Data - R-squared:", r_squared, "\n")

# ----------------------------
# On Testing Data
# ----------------------------
actual_vals_test <- as.numeric(test_data)
predicted_vals_test <- as.numeric(forecast_cpi$mean)

# MSE Calculation
mse_test <- mean((actual_vals_test - predicted_vals_test)^2)
cat("\nTesting Data - Mean Squared Error (MSE):", mse_test, "\n")

# R² Calculation
ss_total_test <- sum((actual_vals_test - mean(actual_vals_test))^2)
ss_res_test <- sum((actual_vals_test - predicted_vals_test)^2)
r_squared_test <- 1 - (ss_res_test / ss_total_test)
cat("Testing Data - R-squared:", r_squared_test, "\n")

# =============================
# 9. Export forecast and residuals to CSV
# =============================
write.csv(as.data.frame(forecast_cpi), "usa_cpi_forecast_output.csv")
write.csv(as.data.frame(residuals(model)), "usa_cpi_residuals.csv")
cat("\nForecast saved as 'usa_cpi_forecast_output.csv'\n")
cat("Residuals saved as 'usa_cpi_residuals.csv'\n")

