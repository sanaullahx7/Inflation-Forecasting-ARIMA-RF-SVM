# =============================
# Load necessary libraries
# =============================
library(readr)      # For reading CSV files
library(forecast)   # For ARIMA forecasting
library(tseries)    # For stationarity tests
library(ggplot2)    # For visualizations

# =============================
# 1. Load the dataset
# =============================
data <- read_csv("final_dataset.csv")
data$observation_date <- as.Date(data$observation_date)

# =============================
# 2. Create a time series object for CPI (quarterly data)
# =============================
cpi_ts <- ts(data$CPIAUCSL, start = c(2010, 2))

# Visualize the Time Series
plot(cpi_ts, main = "CPI Time Series (Original)", col = "blue")

# =============================
# 3. Augmented Dickey-Fuller Test (Stationarity Check)
# =============================
cat("\nAugmented Dickey-Fuller Test Results (Original Series):\n")
adf_result <- adf.test(cpi_ts)
print(adf_result)

# =============================
# 4. Apply Differencing (First and Second Difference)
# =============================
diff_1 <- diff(cpi_ts)
diff_2 <- diff(diff_1)

# Visualize Differences
par(mfrow = c(3, 1))
plot(cpi_ts, main = "Original Time Series", col = "blue")
plot(diff_1, main = "First Difference", col = "green")
plot(diff_2, main = "Second Difference", col = "red")
par(mfrow = c(1, 1))

# =============================
# 5. Stationarity Check after Differencing
# =============================
cat("\nADF Test After First Differencing:\n")
print(adf.test(diff_1))

cat("\nADF Test After Second Differencing:\n")
print(adf.test(diff_2))

# =============================
# 6. ACF and PACF Plots
# =============================
par(mfrow = c(1, 2))
acf(diff_2, main = "ACF of Differenced Data (d=2)")
pacf(diff_2, main = "PACF of Differenced Data (d=2)")
par(mfrow = c(1, 1))

# =============================
# 7. Fit ARIMA Model Based on ACF and PACF
# =============================
cat("\nFitting ARIMA Model Based on ACF and PACF...\n")
# Replace p and q with values you observed
p <- 1  # Example value from PACF
d <- 2  # Because we differenced twice
q <- 1  # Example value from ACF

model <- Arima(cpi_ts, order = c(p, d, q))
summary(model)

# =============================
# 8. Plot Actual vs Fitted CPI Values
# =============================
plot(cpi_ts, main = "Actual vs Fitted CPI", ylab = "CPI", col = "black")
lines(fitted(model), col = "red", lty = 2)
legend("topleft", legend = c("Actual", "Fitted"), col = c("black", "red"), lty = c(1, 2))

# =============================
# 9. Model Evaluation
# =============================
fitted_vals <- fitted(model)
actual_vals <- as.numeric(cpi_ts)

# MSE Calculation
mse <- mean((actual_vals - fitted_vals)^2)
cat("\ Mean Squared Error (MSE):", mse, "\n")

# R² Calculation
ss_total <- sum((actual_vals - mean(actual_vals))^2)
ss_res <- sum((actual_vals - fitted_vals)^2)
r_squared <- 1 - (ss_res / ss_total)
cat("R-squared:", r_squared, "\n")

# =============================
# 10. Forecast Future Data
# =============================
forecast_cpi <- forecast(model, h = 8)
plot(forecast_cpi, main = "Forecast for Next 8 Quarters", col.main = "darkblue")

# =============================
# 11. Export forecast and residuals to CSV
# =============================
write.csv(as.data.frame(forecast_cpi), "usa_cpi_forecast_output.csv")
write.csv(as.data.frame(residuals(model)), "usa_cpi_residuals.csv")
cat("\nForecast saved as 'usa_cpi_forecast_output.csv'\n")
cat("Residuals saved as 'usa_cpi_residuals.csv'\n")

