data <- read.csv("final_dataset.csv")

data$observation_date <- NULL

#Spliting data in test and train-----------------------------------------------

library("caret")
set.seed(56)

# Split the data (70% training, 30% testing)
train_index <- createDataPartition(data$CPIAUCSL, p = 0.7, list = FALSE)

# Create the training and testing dataset
train_data <- data[train_index, ]
test_data <- data[-train_index, ]

# View the first few rows of the training and testing data
head(train_data)
head(test_data)

# Check the dimensions of the dataset
dim(train_data)
dim(test_data)


#Training----------------------------------------------------------------------

library("e1071")

svm_model <- svm(CPIAUCSL ~ ., data = train_data, type = "eps-regression", kernel = "radial")

# Summary of the SVM model
summary(svm_model)


#Predictions and plot----------------------------------------------------------

svm_predictions <- predict(svm_model, test_data)

# Evaluate the model's performance---------------------------------------------

mse <- mean((svm_predictions - test_data$CPIAUCSL)^2)
cat("MSE on Test Data:", mse, "\n")

plot(test_data$CPIAUCSL, svm_predictions, main = "Actual vs Predicted (radial kernel)", 
     xlab = "Actual CPIAUCSL", ylab = "Predicted CPIAUCSL", col = "blue", pch = 16)
abline(0, 1, col = "red")  # Line where actual = predicted

text(x = max(test_data$CPIAUCSL) * 0.75, y = max(svm_predictions) * 0.98, 
     labels = paste("MSE:", round(mse, 2)), col = "black", cex = 1.2)


#Cross-validation(For P and Rvalues)-------------------------------------------


library(caret)
train_control <- trainControl(method = "cv", number = 15)  # 15-fold cross-validation

svm_model_cv <- train(CPIAUCSL ~ ., data = train_data, 
                      method = "svmRadial",  # Radial SVM kernel
                      trControl = train_control)

print(svm_model_cv)

svm_model_cv$results

#Variable Importance-----------------------------------------------------------

importance <- varImp(svm_model_cv)
print(importance)
