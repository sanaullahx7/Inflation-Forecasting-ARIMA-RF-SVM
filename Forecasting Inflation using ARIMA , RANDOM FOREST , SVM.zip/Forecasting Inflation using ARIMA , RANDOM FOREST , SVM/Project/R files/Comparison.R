# Load necessary libraries
install.packages(c("readr", "forecast", "tseries", "ggplot2", "randomForest", "e1071", "caret", "Metrics", "dplyr"))

library(readr)

library(forecast)
library(tseries)
library(ggplot2)
library(randomForest)
library(e1071)
library(caret)
library(Metrics)
library(dplyr)

# Load the dataset
data <- read_csv("final_dataset.csv")
data$observation_date <- as.Date(data$observation_date)

# Create a time series object for CPI (quarterly data)
cpi_ts <- ts(data$CPIAUCSL, frequency = 4)

# 1. ARIMA Model
arima_model <- auto.arima(cpi_ts)
arima_forecast <- forecast(arima_model, h = 8)  # Forecast for 8 quarters
arima_pred <- c(fitted(arima_model), as.numeric(arima_forecast$mean))
arima_dates <- data$observation_date

# 2. Random Forest Model
model_data <- data %>% select(-observation_date)
target_variable <- "CPIAUCSL"
predictor_variables <- setdiff(names(model_data), target_variable)

set.seed(123)
train_indices <- sample(1:nrow(model_data), 0.8 * nrow(model_data))
train_data <- model_data[train_indices, ]
test_data <- model_data[-train_indices, ]

test_X <- test_data %>% select(all_of(predictor_variables))
test_y <- test_data[[target_variable]]

formula_str <- paste(target_variable, "~", paste(predictor_variables, collapse = " + "))
model_formula <- as.formula(formula_str)

rf_model <- randomForest(
  formula = model_formula,
  data = train_data,
  importance = TRUE,
  na.action = na.omit
)

rf_predictions <- predict(rf_model, newdata = model_data) # Predict on entire dataset
rf_dates <- data$observation_date

# 3. SVM Model
data_svm <- data %>% select(-observation_date)

set.seed(56)
train_index_svm <- createDataPartition(data_svm$CPIAUCSL, p = 0.7, list = FALSE)
train_data_svm <- data_svm[train_index_svm, ]
test_data_svm <- data_svm[-train_index_svm, ]

svm_model <- svm(CPIAUCSL ~ ., data = train_data_svm, type = "eps-regression", kernel = "radial")
svm_predictions <- predict(svm_model, data_svm)
svm_dates <- data$observation_date

# Create combined data for plotting
plot_data <- data.frame(
  Date = data$observation_date,
  Actual = data$CPIAUCSL,
  ARIMA = as.numeric(arima_pred),
  RF = as.numeric(rf_predictions),
  SVM = as.numeric(svm_predictions)
)

plot_data_long <- plot_data %>%
  pivot_longer(cols = c(Actual, ARIMA, RF, SVM), names_to = "Model", values_to = "CPI")

# Plot the results
ggplot(plot_data_long, aes(x = Date, y = CPI, color = Model)) +
  geom_line() +
  labs(
    title = "Comparison of CPI Forecasts",
    x = "Date",
    y = "CPIAUCSL",
    color = "Model"
  ) +
  theme_minimal() +
  scale_color_manual(values = c("Actual" = "black", "ARIMA" = "blue", "RF" = "red", "SVM" = "green"))