library(randomForest)
library(Metrics)
library(dplyr)
library(ggplot2)

# --- Step 1: Loading Data ---
data <- read.csv("C:/Users/Muddassir/Desktop/Adv Stats/Project/final_dataset.csv")

# --- Step 2: Preparing Data ---
data$observation_date <- as.Date(data$observation_date)

# Selecting relevant columns (predictors and target), excluding 'observation_date'
model_data <- data %>% select(-observation_date)

# Defining target variable
target_variable <- "CPIAUCSL"

# Defining predictor variables
predictor_variables <- setdiff(names(model_data), target_variable)

# --- Step 3: Splitting Data ---
set.seed(123) # for reproducibility 
train_indices <- sample(1:nrow(model_data), 0.8 * nrow(model_data))
train_data <- model_data[train_indices, ]
test_data <- model_data[-train_indices, ]

# Separating predictors (X) and target (y) for test set for easier evaluation
test_X <- test_data %>% select(all_of(predictor_variables))
test_y <- test_data[[target_variable]]

# --- Step 4: Training Model ---
# Building the formula for the model
formula_str <- paste(target_variable, "~", paste(predictor_variables, collapse = " + "))
model_formula <- as.formula(formula_str)

# Train the Random Forest model
# Using default parameters for ntree (500) and mtry (number_of_predictors / 3)
rf_model <- randomForest(
  formula = model_formula,
  data = train_data,
  importance = TRUE,
  na.action = na.omit # Handle potential NAs just in case
)

# model summary
print("Random Forest Model Summary:")
print(rf_model)

# --- Step 5: Make Predictions ---
predictions <- predict(rf_model, newdata = test_X)

# --- Step 6: Evaluate Model ---
# RMSE
rmse_value <- rmse(actual = test_y, predicted = predictions)
print(paste("Root Mean Squared Error (RMSE) on Test Set:", round(rmse_value, 4)))

# R-squared
mean_y_test <- mean(test_y)
ss_total <- sum((test_y - mean_y_test)^2) # Total sum of squares (SST)
ss_residual <- sum((test_y - predictions)^2) # Residual sum of squares (SSR)
r_squared <- 1 - (ss_residual / ss_total)
print(paste("R-squared (R²) on Test Set:", round(r_squared, 4)))

# Model performance on the Out-Of-Bag samples during training (not the test set)
final_oob_mse <- rf_model$mse[length(rf_model$mse)]
final_oob_rsq <- rf_model$rsq[length(rf_model$rsq)]
print(paste("Final Mean of Squared Residuals (OOB MSE):", round(final_oob_mse, 4)))
print(paste("Final % Var Explained (OOB R²):", round(final_oob_rsq * 100, 2), "%"))


# Variable Importance Scores
print("\nVariable Importance Scores:")
importance_scores <- importance(rf_model)
print(importance_scores)

# --- Step 7: Visualize Model Performance ---

# 1. Variable Importance Plot
print("\nGenerating Variable Importance Plot...")
varImpPlot(rf_model, main = "Variable Importance Plot (Random Forest)")

# Actual and Predicted Values along with errors
results_df <- data.frame(
  Actual = test_y,
  Predicted = predictions,
  Residuals = test_y - predictions
)

# 2. Actual vs. Predicted Plot
print("\nGenerating Actual vs. Predicted Plot...")
plot_actual_vs_predicted <- ggplot(results_df, aes(x = Actual, y = Predicted)) +
  geom_point(alpha = 0.7, color = "blue") +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "red") +
  labs(
    title = "Actual vs. Predicted Values (Test Set)",
    x = "Actual CPIAUCSL",
    y = "Predicted CPIAUCSL"
  ) +
  theme_minimal()
print(plot_actual_vs_predicted)

# 3. Residuals vs. Predicted Plot
print("\nGenerating Residuals vs. Predicted Plot...")
plot_residuals <- ggplot(results_df, aes(x = Predicted, y = Residuals)) +
  geom_point(alpha = 0.7, color = "darkgreen") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(
    title = "Residuals vs. Predicted Values (Test Set)",
    x = "Predicted CPIAUCSL",
    y = "Residuals (Actual - Predicted)"
  ) +
  theme_minimal()
print(plot_residuals)

# 4. OOB Error Plot (using ggplot2)
# Extract OOB error (MSE) vs. number of trees
oob_error_data <- data.frame(
  Trees = 1:length(rf_model$mse),
  OOB_MSE = rf_model$mse
)

print("\nGenerating OOB Error Plot...")
plot_oob_error <- ggplot(oob_error_data, aes(x = Trees, y = OOB_MSE)) +
  geom_line(color = "purple") +
  labs(
    title = "Out-of-Bag (OOB) Error vs. Number of Trees",
    x = "Number of Trees",
    y = "OOB Mean Squared Error (MSE)"
  ) +
  theme_minimal()
print(plot_oob_error)
